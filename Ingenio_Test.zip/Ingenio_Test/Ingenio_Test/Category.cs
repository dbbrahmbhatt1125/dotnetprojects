﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ingenio_Test
{
    public class Category
    {
        public Category(int categoryId, string name, string keywords = null, Category parentCategory = null)
        {
            this.CategoryId = categoryId;
            this.Name = name;
            this.Keywords = keywords;
            this.ParentCategory = parentCategory;
        }
        public int CategoryId { get; set; }
        public Category ParentCategory { get; set; }
        public string Name { get; set; }
        public string Keywords { get; set; }
    }
}
