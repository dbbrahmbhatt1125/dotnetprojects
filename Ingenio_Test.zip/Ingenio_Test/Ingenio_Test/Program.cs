﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ingenio_Test
{
    class Program
    {
        static List<Category> lstCategories = new List<Category>();
        static void Main(string[] args)
        {
            AddCategories();
            while (true)
            {
                Console.WriteLine("Enter your choice(Press 1,2 or 3 and hit enter)");
                Console.WriteLine("1. Print All Catergories");
                Console.WriteLine("2. Get Category Details");
                Console.WriteLine("3. Get Nth Level Categories");
                int i;
                if (int.TryParse(Console.ReadLine(), out i))
                {
                    if (i == 1)
                        PrintAllCategories();
                    else if (i == 2)
                        GetCategoryDetails();
                    else if (i == 3)
                        GetNLevelCategories();
                    else
                        Console.WriteLine("Invalid Choice");
                }
                else
                {
                    Console.WriteLine("Invalid Entry");
                }
            }

        }
        private static void AddCategories()
        {
            Category c100 = new Category(100, "Business", "Money");
            lstCategories.Add(c100);
            Category c200 = new Category(200, "Tutoring", "Teaching");
            lstCategories.Add(c200);
            Category c101 = new Category(101, "Accounting", "Taxes", c100);
            lstCategories.Add(c101);
            Category c102 = new Category(102, "Taxation", parentCategory: c100);
            lstCategories.Add(c102);
            Category c201 = new Category(201, "Computer", parentCategory: c200);
            lstCategories.Add(c201);
            Category c103 = new Category(103, "Corporate Tax", parentCategory: c101);
            lstCategories.Add(c103);
            Category c202 = new Category(202, "Operating System", parentCategory: c201);
            lstCategories.Add(c202);
            Category c109 = new Category(109, "Small Business Tax", parentCategory: c101);
            lstCategories.Add(c109);
        }
        private static void PrintAllCategories()
        {

            Console.WriteLine("-------------------------------------------------------------------------------------------------");
            Console.WriteLine(string.Format("{0,6} {1,25} {2,30} {3,20}", "Category Id", "Parent Category Id", "Name", "Keywords"));
            foreach (Category c in lstCategories)
            {
                Console.WriteLine(string.Format("{0,6} {1,25} {2,35} {3,20}", c.CategoryId, c.ParentCategory == null ? -1 : c.ParentCategory.CategoryId, c.Name, c.Keywords));
            }
            Console.WriteLine("-------------------------------------------------------------------------------------------------");
        }

        private static void GetCategoryDetails()
        {
            Console.Write("Enter Category ID : ");
            int CategoryId;
            if (int.TryParse(Console.ReadLine(), out CategoryId))
            {
                Console.WriteLine("-------------------------------------------------------------------------------------------------");
                Category category = lstCategories.SingleOrDefault<Category>(c => c.CategoryId == CategoryId);
                if (category != null)
                {
                    Console.WriteLine(string.Format("Category Id : {0}", category.CategoryId));
                    Console.WriteLine(string.Format("Parent Category Id : {0}", category.ParentCategory == null ? -1 : category.ParentCategory.CategoryId));
                    Console.WriteLine(string.Format("Name : {0}", category.Name));
                    while (string.IsNullOrEmpty(category.Keywords))
                    {
                        category = category.ParentCategory;
                    }
                    Console.WriteLine(string.Format("Keywords : {0}", category.Keywords));
                }
                else
                {
                    Console.WriteLine("Category Not found");
                }
                Console.WriteLine("-------------------------------------------------------------------------------------------------\n\n");
            }
            else
            {
                Console.WriteLine("Invalid Category\n\n");
            }
        }
        private static int GetLevelCount(Category c)
        {
            if (c.ParentCategory == null)
            {
                return 1;
            }
            return 1 + GetLevelCount(c.ParentCategory);
        }
        private static void GetNLevelCategories()
        {
            Console.Write("Enter Level : ");
            int level;
            bool categoryFound = false;
            string strCategories = "Categories Found :";
            if (int.TryParse(Console.ReadLine(), out level))
            {
                Console.WriteLine("-------------------------------------------------------------------------------------------------");
                foreach (Category c in lstCategories)
                {
                    int lvlCount = GetLevelCount(c);
                    if (lvlCount == level)
                    {
                        strCategories += " " + c.CategoryId + ",";
                        categoryFound = true;
                    }

                }

                if (categoryFound)
                {
                    Console.WriteLine(strCategories.TrimEnd(','));
                }
                else
                {
                    Console.WriteLine("No Category Exist at this level");
                }
                Console.WriteLine("-------------------------------------------------------------------------------------------------\n\n");
            }
            else
            {
                Console.WriteLine("Invalid Level Number\n\n");
            }
        }

    }
}
